(function () {
    var app = angular.module('app');
    var map = new L.Map('mapid', {center: new L.LatLng(-23.18, -46.89), zoom: 9});
    L.tileLayer('https://maps.googleapis.com/maps/vt?pb=!1m5!1m4!1i{z}!2i{x}!3i{y}!4i256!2m3!1e0!2sm!3i349018013!3m9!2sen-US!3sUS!5e18!12m1!1e47!12m3!1e37!2m1!1ssmartmaps!4e0').addTo(map);

    var googleKey = "AIzaSyDyt4MRunBjbBOt9IiKJbDEhZYosIgA5q8",
        googleURL = "https://maps.googleapis.com/maps/api/geocode/json?",
        googleParam = "&address=",
        googleRequest = googleURL + (googleKey ? "&key=" + googleKey : "") + googleParam;

    app.controller('formController', formController);

    var dataModel = {
        cliente:{value:'',type:'text',class:'form-group',placeholder:'Nome do Cliente',required:1,disabled:0},
        peso:{value:'',type:'number',class:'form-group',placeholder:'Peso da Entrega (kg)',required:1,disabled:0},
        endereco:{value:'',type:'text',class:'form-group',placeholder:'Endereço Cliente',required:1,disabled:0},
        complemento:{value:'',type:'text',class:'form-group',placeholder:'Complemento',required:0,disabled:0},
        logradouro:{value:'',type:'hidden',class:'form-group',placeholder:'logradouro',required:0,disabled:0},
        numero:{value:'',type:'hidden',class:'form-group',placeholder:'numero',required:0,disabled:0},
        bairro:{value:'',type:'hidden',class:'form-group',placeholder:'bairro',required:0,disabled:0},
        cidade:{value:'',type:'hidden',class:'form-group',placeholder:'cidade',required:0,disabled:0},
        estado:{value:'',type:'hidden',class:'form-group',placeholder:'estado',required:0,disabled:0},
        pais:{value:'',type:'hidden',class:'form-group',placeholder:'pais',required:0,disabled:0},
        latitude:{value:'',type:'text',class:'form-group',placeholder:'latitude',required:0,disabled:1},
        longitude:{value:'',type:'text',class:'form-group',placeholder:'longitude',required:0,disabled:1}                                                    
    }

    const googleModel = {
        route: ['logradouro','long_name'],
        street_number: ['numero','short_name'],
        sublocality_level_1: ['bairro','long_name'],
        administrative_area_level_2: ['cidade','long_name'],
        administrative_area_level_1: ['estado','long_name'],
        country: ['pais','long_name']
    }

    function formController($scope,$http){
        $scope.dados = dataModel;

        $scope.searchMap = function($event){
            $event.preventDefault();
            $http.get(googleRequest + encodeURI($scope.dados.endereco.value)).then(function(response) {
                //verifica se a quantidade de endereços procurado é > 0
                if (response.data.results.length > 0){
                    //atribui ao primeiro resultado (endereço) da lista
                    var result = response.data.results[0];
                    //altera o endereço para o formato válido do resultado
                    $scope.dados.endereco.value = result.formatted_address;
                    //loop: lista todos os campos de endereço do resultado
                    for (var i = 0; i < result.address_components.length; i++){
                        var dataComponent = false, dataType = false;
                        //procura os resultados da pesquisa se existem no googleModel
                        for (index in result.address_components[i].types){
                            if (googleModel[ result.address_components[i].types[index] ] ){
                                //atribui o correspondente do googleModel ao dataModel
                                dataComponent = googleModel[ result.address_components[i].types[index] ][0];
                                //atribui o tipo de dado "long_name" ou "short_name"
                                dataType = googleModel[ result.address_components[i].types[index] ][1];
                                //atribui o valor do componente aos dados
                                var val = result.address_components[i][ dataType ];
                                $scope.dados[ dataComponent ].value = val;
                                break;
                            }
                        }
                    }
                    //preenche a latitude e longitude
                    $scope.dados.latitude.value = result.geometry.location.lat;
                    $scope.dados.longitude.value = result.geometry.location.lng;
                    
                    //focaliza a posição no endereço
                    var latlng = [result.geometry.location.lat, result.geometry.location.lng];
                    map.setView(latlng, 16);
                    //adiciona um popup no endereço informado
                    L.popup()
                        .setLatLng(latlng)
                        .setContent($scope.dados.endereco.value)
                        .openOn(map);
                }
            });
            return false;
        }

        $scope.submit = function () {
            /*
            var postData = {};
            for (index in $scope.dados){
                postData[index] = $scope.dados[index].value;
            }
            */
            console.log(dataModel);
        }
    }

    
    app.controller('enderecoController', function($scope) {
        $scope.campos = componenteEndereco;
    });

    app.directive('inputemplate',function(){
        return {
            template: '<input type="{{x.type}}" class="form-control" placeholder="{{x.placeholder}}" ng-model="x.value" ng-disabled="x.disabled" ng-required="x.required">'
          };
    });

    app.factory('test1',['$window',function(win){
        return function(){
            win.alert('test1');
        }
    }]);

    app.factory('test2',['$window',function(win){
        return function(){
            win.alert('test2');
        }
    }]);

    app.controller('testcontrol',['$scope','test1','test2',function($scope,test1,test2){
        $scope.test1 = function(){
            test1();
        }
        $scope.test2 = function(){
            test2();
        }
    }]);


})();